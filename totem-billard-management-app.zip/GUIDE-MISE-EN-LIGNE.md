# TOTEM BILLARD – Mise en ligne gratuite depuis un iPhone

Tout se fait dans Safari, sans rien installer et sans payer.
Trois services gratuits : **GitHub** (stocke le code), **Neon** (base de données partagée), **Vercel** (met le site en ligne).

## Étape 1 – Base de données (Neon)
1. Va sur **neon.tech** → « Sign up » (avec Google ou email).
2. Crée un projet (nom : `totem-billard`, région Europe).
3. Sur le tableau de bord, clique sur **Connect** et copie la **Connection string**
   (elle commence par `postgresql://...`). Garde-la dans tes Notes.
   Les tables se créent toutes seules au premier lancement du site.

## Étape 2 – Le code (GitHub)
1. Va sur **github.com** → crée un compte gratuit.
2. Crée un dépôt (« New repository ») nommé `totem-billard`, en **Private**.
3. Ajoute les fichiers du projet (« Add file » → « Upload files »).
   Astuce : depuis l'app Fichiers de l'iPhone, décompresse le ZIP du projet, puis envoie les dossiers.
   Ne pas envoyer : `node_modules`, `.next`, `.env`.

## Étape 3 – Mise en ligne (Vercel)
1. Va sur **vercel.com** → « Sign up » → « Continue with GitHub ».
2. « Add New… » → « Project » → choisis `totem-billard` → « Import ».
3. Ouvre **Environment Variables** et ajoute :
   - Nom : `DATABASE_URL`
   - Valeur : la connection string Neon copiée à l'étape 1
4. Clique sur **Deploy**. Après ~1 minute tu obtiens une adresse `https://totem-billard-xxx.vercel.app`.

## Étape 4 – Sur l'écran d'accueil
Ouvre l'adresse dans Safari → bouton Partager → « Sur l'écran d'accueil ».
Partage la même adresse à tes autres téléphones : les données sont communes.

## Utilisation
1. **Joueurs** : ajoute tes joueurs (nom + pseudo).
2. **Tournois** : crée un tournoi, coche les inscrits.
3. Après le tournoi : choisis champion, finaliste (et demi-finalistes si tu veux), puis « Valider ».
4. **Classement** : mis à jour automatiquement.

Barème (fichier `src/lib/points.ts`) : participation 10 · demi-finaliste 40 · finaliste 60 · champion 100.

## À savoir
- Le site n'a pas de mot de passe : toute personne ayant l'adresse peut modifier les données. Ne partage le lien qu'avec les organisateurs.
- Les offres gratuites de Neon et Vercel suffisent largement pour un club.
