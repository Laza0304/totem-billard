"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const items = [
  { href: "/", label: "Classement", icon: "🏆" },
  { href: "/tournois", label: "Tournois", icon: "🎱" },
  { href: "/joueurs", label: "Joueurs", icon: "👥" },
];

export default function Nav() {
  const pathname = usePathname();
  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-50 border-t border-gold/30 bg-black/95 backdrop-blur"
      style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
    >
      <ul className="mx-auto flex max-w-xl">
        {items.map((it) => {
          const active =
            it.href === "/" ? pathname === "/" : pathname.startsWith(it.href);
          return (
            <li key={it.href} className="flex-1">
              <Link
                href={it.href}
                className={`flex flex-col items-center gap-0.5 py-2.5 text-xs font-semibold ${
                  active ? "text-gold" : "text-white/55"
                }`}
              >
                <span className="text-xl leading-none">{it.icon}</span>
                {it.label}
                <span
                  className={`mt-0.5 h-0.5 w-8 rounded ${active ? "bg-gold" : "bg-transparent"}`}
                />
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
