import { pool } from "@/db";

// Crée les tables automatiquement si elles n'existent pas encore.
// Ainsi, aucune commande n'est nécessaire pour la mise en ligne.
let ready: Promise<void> | null = null;

export function ensureTables(): Promise<void> {
  if (!ready) {
    ready = (async () => {
      await pool.query(`
        CREATE TABLE IF NOT EXISTS players (
          id serial PRIMARY KEY,
          name text NOT NULL,
          nickname text NOT NULL,
          created_at timestamp NOT NULL DEFAULT now()
        );
        CREATE TABLE IF NOT EXISTS tournaments (
          id serial PRIMARY KEY,
          name text NOT NULL,
          date text NOT NULL,
          status text NOT NULL DEFAULT 'open',
          created_at timestamp NOT NULL DEFAULT now()
        );
        CREATE TABLE IF NOT EXISTS registrations (
          id serial PRIMARY KEY,
          tournament_id integer NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
          player_id integer NOT NULL REFERENCES players(id) ON DELETE CASCADE,
          result text NOT NULL DEFAULT 'participant',
          CONSTRAINT registrations_unique UNIQUE (tournament_id, player_id)
        );
      `);
    })().catch((e) => {
      ready = null;
      throw e;
    });
  }
  return ready;
}
