import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import Nav from "@/components/Nav";
import "./globals.css";

export const metadata: Metadata = {
  title: "TOTEM BILLARD",
  description: "Gestion des joueurs, tournois et classement du club.",
  appleWebApp: { capable: true, title: "TOTEM BILLARD", statusBarStyle: "black-translucent" },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
  themeColor: "#0a0a0a",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fr">
      <body className="antialiased">
        <header
          className="px-5 pb-3 text-center"
          style={{ paddingTop: "calc(env(safe-area-inset-top) + 1rem)" }}
        >
          <div className="text-xs tracking-[0.4em] text-gold/80">CLUB</div>
          <h1 className="text-2xl font-black tracking-widest text-gold">
            TOTEM <span className="text-white">BILLARD</span>
          </h1>
        </header>
        <main className="mx-auto w-full max-w-xl px-4 pb-32">{children}</main>
        <Nav />
      </body>
    </html>
  );
}
