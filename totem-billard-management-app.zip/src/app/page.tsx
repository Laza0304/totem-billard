import Link from "next/link";
import { getRanking } from "@/lib/data";
import { POINTS } from "@/lib/points";

export const dynamic = "force-dynamic";

const medal = (rank: number) =>
  rank === 1 ? "🥇" : rank === 2 ? "🥈" : rank === 3 ? "🥉" : String(rank);

export default async function RankingPage() {
  const ranking = await getRanking();

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold text-gold">Classement général</h2>

      {ranking.length === 0 ? (
        <div className="card p-6 text-center text-white/70">
          Aucun joueur pour le moment.
          <br />
          <Link href="/joueurs" className="mt-2 inline-block font-bold text-gold underline">
            Ajouter un joueur
          </Link>
        </div>
      ) : (
        <ol className="space-y-2">
          {ranking.map((p) => (
            <li
              key={p.id}
              className={`card flex items-center gap-3 px-4 py-3 ${
                p.rank === 1 && p.points > 0 ? "border-gold! bg-felt-dark/60" : ""
              }`}
            >
              <div className="w-9 text-center text-xl font-black text-gold">
                {medal(p.rank)}
              </div>
              <div className="min-w-0 flex-1">
                <div className="truncate font-bold">{p.nickname}</div>
                <div className="truncate text-sm text-white/55">
                  {p.name} · {p.tournaments} tournoi{p.tournaments > 1 ? "s" : ""}
                  {p.wins > 0 ? ` · ${p.wins} 🏆` : ""}
                </div>
              </div>
              <div className="text-right">
                <div className="text-2xl font-black leading-none text-gold">
                  {p.points}
                </div>
                <div className="text-[10px] uppercase tracking-wider text-white/50">
                  pts
                </div>
              </div>
            </li>
          ))}
        </ol>
      )}

      <div className="card p-4 text-sm text-white/70">
        <div className="mb-1 font-bold text-gold-soft">Barème</div>
        Participation {POINTS.participant} · Demi-finaliste {POINTS.semi} ·
        Finaliste {POINTS.finalist} · Champion {POINTS.champion}
      </div>
    </div>
  );
}
