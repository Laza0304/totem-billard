import { addPlayer, deletePlayer, updatePlayer } from "@/app/actions";
import ConfirmButton from "@/components/ConfirmButton";
import { getPlayers } from "@/lib/data";

export const dynamic = "force-dynamic";

export default async function PlayersPage() {
  const players = await getPlayers();

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold text-gold">Joueurs ({players.length})</h2>

      <form action={addPlayer} className="card space-y-3 p-4">
        <div className="font-bold text-gold-soft">Nouveau joueur</div>
        <input name="name" required placeholder="Nom" className="field" autoComplete="off" />
        <input name="nickname" required placeholder="Pseudonyme" className="field" autoComplete="off" />
        <button className="btn btn-gold w-full">Ajouter</button>
      </form>

      {players.length === 0 && (
        <p className="text-center text-white/60">Aucun joueur pour le moment.</p>
      )}

      <ul className="space-y-2">
        {players.map((p) => (
          <li key={p.id} className="card">
            <details>
              <summary className="flex cursor-pointer list-none items-center justify-between gap-3 px-4 py-3">
                <div className="min-w-0">
                  <div className="truncate font-bold">{p.nickname}</div>
                  <div className="truncate text-sm text-white/55">{p.name}</div>
                </div>
                <span className="text-sm font-semibold text-gold">Modifier ›</span>
              </summary>
              <div className="space-y-3 border-t border-gold/20 p-4">
                <form action={updatePlayer} className="space-y-3">
                  <input type="hidden" name="id" value={p.id} />
                  <input name="name" required defaultValue={p.name} className="field" />
                  <input name="nickname" required defaultValue={p.nickname} className="field" />
                  <button className="btn btn-green w-full">Enregistrer</button>
                </form>
                <form action={deletePlayer}>
                  <input type="hidden" name="id" value={p.id} />
                  <ConfirmButton
                    message={`Supprimer ${p.nickname} ? Ses points seront perdus.`}
                    className="btn btn-danger w-full"
                  >
                    Supprimer
                  </ConfirmButton>
                </form>
              </div>
            </details>
          </li>
        ))}
      </ul>
    </div>
  );
}
