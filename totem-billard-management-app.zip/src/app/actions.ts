"use server";

import { and, eq, inArray, notInArray } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { db } from "@/db";
import { ensureTables } from "@/db/init";
import { players, registrations, tournaments } from "@/db/schema";

function str(formData: FormData, key: string): string {
  const v = formData.get(key);
  return typeof v === "string" ? v.trim() : "";
}

function num(formData: FormData, key: string): number {
  const n = Number(str(formData, key));
  return Number.isInteger(n) && n > 0 ? n : 0;
}

function refresh() {
  revalidatePath("/", "layout");
}

/* ---------- JOUEURS ---------- */

export async function addPlayer(formData: FormData): Promise<void> {
  await ensureTables();
  const name = str(formData, "name");
  const nickname = str(formData, "nickname");
  if (!name || !nickname) return;
  await db.insert(players).values({ name, nickname });
  refresh();
}

export async function updatePlayer(formData: FormData): Promise<void> {
  await ensureTables();
  const id = num(formData, "id");
  const name = str(formData, "name");
  const nickname = str(formData, "nickname");
  if (!id || !name || !nickname) return;
  await db.update(players).set({ name, nickname }).where(eq(players.id, id));
  refresh();
}

export async function deletePlayer(formData: FormData): Promise<void> {
  await ensureTables();
  const id = num(formData, "id");
  if (!id) return;
  await db.delete(players).where(eq(players.id, id));
  refresh();
}

/* ---------- TOURNOIS ---------- */

export async function createTournament(formData: FormData): Promise<void> {
  await ensureTables();
  const name = str(formData, "name");
  const date = str(formData, "date") || new Date().toISOString().slice(0, 10);
  if (!name) return;
  const [t] = await db
    .insert(tournaments)
    .values({ name, date })
    .returning({ id: tournaments.id });
  refresh();
  redirect(`/tournois/${t.id}`);
}

export async function deleteTournament(formData: FormData): Promise<void> {
  await ensureTables();
  const id = num(formData, "id");
  if (!id) return;
  await db.delete(tournaments).where(eq(tournaments.id, id));
  refresh();
  redirect("/tournois");
}

// Synchronise la liste des inscrits avec les cases cochées.
export async function saveRegistrations(formData: FormData): Promise<void> {
  await ensureTables();
  const tournamentId = num(formData, "tournamentId");
  if (!tournamentId) return;
  const ids = formData
    .getAll("playerId")
    .map((v) => Number(v))
    .filter((n) => Number.isInteger(n) && n > 0);

  if (ids.length === 0) {
    await db
      .delete(registrations)
      .where(eq(registrations.tournamentId, tournamentId));
  } else {
    await db
      .delete(registrations)
      .where(
        and(
          eq(registrations.tournamentId, tournamentId),
          notInArray(registrations.playerId, ids),
        ),
      );
    await db
      .insert(registrations)
      .values(ids.map((playerId) => ({ tournamentId, playerId })))
      .onConflictDoNothing();
  }
  refresh();
}

/* ---------- RÉSULTATS ---------- */

// Enregistre champion / finaliste / demi-finalistes.
// Les points sont ensuite calculés automatiquement dans le classement.
export async function saveResults(formData: FormData): Promise<void> {
  await ensureTables();
  const tournamentId = num(formData, "tournamentId");
  const champion = num(formData, "champion");
  const finalist = num(formData, "finalist");
  const semis = [num(formData, "semi1"), num(formData, "semi2")].filter(
    (n) => n > 0,
  );
  if (!tournamentId || !champion || !finalist) return;

  const chosen = [champion, finalist, ...semis];
  if (new Set(chosen).size !== chosen.length) {
    redirect(`/tournois/${tournamentId}?erreur=doublon`);
  }

  const entries = await db
    .select({ playerId: registrations.playerId })
    .from(registrations)
    .where(eq(registrations.tournamentId, tournamentId));
  const registered = new Set(entries.map((e) => e.playerId));
  if (!chosen.every((id) => registered.has(id))) return;

  const setResult = (result: string, ids: number[]) =>
    ids.length
      ? db
          .update(registrations)
          .set({ result })
          .where(
            and(
              eq(registrations.tournamentId, tournamentId),
              inArray(registrations.playerId, ids),
            ),
          )
      : Promise.resolve();

  await db
    .update(registrations)
    .set({ result: "participant" })
    .where(eq(registrations.tournamentId, tournamentId));
  await setResult("semi", semis);
  await setResult("finalist", [finalist]);
  await setResult("champion", [champion]);
  await db
    .update(tournaments)
    .set({ status: "done" })
    .where(eq(tournaments.id, tournamentId));
  refresh();
  redirect(`/tournois/${tournamentId}`);
}

// Annule les résultats (retire les points) pour pouvoir les saisir à nouveau.
export async function reopenTournament(formData: FormData): Promise<void> {
  await ensureTables();
  const tournamentId = num(formData, "tournamentId");
  if (!tournamentId) return;
  await db
    .update(registrations)
    .set({ result: "participant" })
    .where(eq(registrations.tournamentId, tournamentId));
  await db
    .update(tournaments)
    .set({ status: "open" })
    .where(eq(tournaments.id, tournamentId));
  refresh();
}
