import Link from "next/link";
import { createTournament } from "@/app/actions";
import { getTournaments } from "@/lib/data";

export const dynamic = "force-dynamic";

function formatDate(d: string) {
  const [y, m, day] = d.split("-");
  return y && m && day ? `${day}/${m}/${y}` : d;
}

export default async function TournamentsPage() {
  const list = await getTournaments();
  const today = new Date().toISOString().slice(0, 10);

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold text-gold">Tournois</h2>

      <form action={createTournament} className="card space-y-3 p-4">
        <div className="font-bold text-gold-soft">Nouveau tournoi</div>
        <input name="name" required placeholder="Nom du tournoi" className="field" autoComplete="off" />
        <input name="date" type="date" defaultValue={today} required className="field" />
        <button className="btn btn-gold w-full">Créer le tournoi</button>
      </form>

      {list.length === 0 && (
        <p className="text-center text-white/60">Aucun tournoi pour le moment.</p>
      )}

      <ul className="space-y-2">
        {list.map((t) => (
          <li key={t.id}>
            <Link href={`/tournois/${t.id}`} className="card flex items-center justify-between gap-3 px-4 py-3">
              <div className="min-w-0">
                <div className="truncate font-bold">{t.name}</div>
                <div className="text-sm text-white/55">
                  {formatDate(t.date)} · {t.count} inscrit{t.count > 1 ? "s" : ""}
                </div>
              </div>
              <span
                className={`shrink-0 rounded-full px-3 py-1 text-xs font-bold ${
                  t.status === "done"
                    ? "bg-gold text-black"
                    : "bg-felt text-white"
                }`}
              >
                {t.status === "done" ? "Terminé" : "En cours"}
              </span>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
