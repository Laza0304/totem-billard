import Link from "next/link";
import { notFound } from "next/navigation";
import {
  deleteTournament,
  reopenTournament,
  saveRegistrations,
  saveResults,
} from "@/app/actions";
import ConfirmButton from "@/components/ConfirmButton";
import { getPlayers, getTournament } from "@/lib/data";
import { POINTS, RESULT_LABELS } from "@/lib/points";

export const dynamic = "force-dynamic";

const ORDER = ["champion", "finalist", "semi", "participant"] as const;

export default async function TournamentPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ erreur?: string }>;
}) {
  const { id } = await params;
  const { erreur } = await searchParams;
  const tid = Number(id);
  if (!Number.isInteger(tid)) notFound();

  const data = await getTournament(tid);
  if (!data) notFound();
  const { tournament, entries } = data;
  const allPlayers = await getPlayers();
  const done = tournament.status === "done";
  const registeredIds = new Set(entries.map((e) => e.playerId));

  const sorted = [...entries].sort(
    (a, b) =>
      ORDER.indexOf(a.result as (typeof ORDER)[number]) -
      ORDER.indexOf(b.result as (typeof ORDER)[number]),
  );

  return (
    <div className="space-y-4">
      <Link href="/tournois" className="text-sm font-semibold text-gold">
        ‹ Tous les tournois
      </Link>

      <div>
        <h2 className="text-xl font-bold text-gold">{tournament.name}</h2>
        <div className="text-sm text-white/55">
          {tournament.date} · {done ? "Terminé" : "Inscriptions en cours"}
        </div>
      </div>

      {done ? (
        <section className="card space-y-3 p-4">
          <div className="font-bold text-gold-soft">Résultats</div>
          <ul className="space-y-2">
            {sorted.map((e) => (
              <li key={e.playerId} className="flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <span className="font-bold">{e.nickname}</span>{" "}
                  <span className="text-sm text-white/50">{e.name}</span>
                  <div className="text-xs text-gold-soft">
                    {e.result === "champion" && "🏆 "}
                    {RESULT_LABELS[e.result]}
                  </div>
                </div>
                <div className="shrink-0 font-black text-gold">
                  +{POINTS[e.result as keyof typeof POINTS]} pts
                </div>
              </li>
            ))}
          </ul>
          <p className="text-xs text-white/50">
            Les points sont déjà ajoutés au classement.
          </p>
          <form action={reopenTournament}>
            <input type="hidden" name="tournamentId" value={tournament.id} />
            <ConfirmButton
              message="Annuler les résultats et retirer les points de ce tournoi ?"
              className="btn btn-ghost w-full"
            >
              Corriger les résultats
            </ConfirmButton>
          </form>
        </section>
      ) : (
        <>
          <form action={saveRegistrations} className="card space-y-3 p-4">
            <input type="hidden" name="tournamentId" value={tournament.id} />
            <div className="font-bold text-gold-soft">
              Inscriptions ({entries.length})
            </div>
            {allPlayers.length === 0 ? (
              <p className="text-sm text-white/60">
                Ajoute d&apos;abord des joueurs dans l&apos;onglet Joueurs.
              </p>
            ) : (
              <ul className="space-y-1">
                {allPlayers.map((p) => (
                  <li key={p.id}>
                    <label className="flex min-h-12 cursor-pointer items-center gap-3 rounded-lg px-2 active:bg-white/5">
                      <input
                        type="checkbox"
                        name="playerId"
                        value={p.id}
                        defaultChecked={registeredIds.has(p.id)}
                        className="h-6 w-6 accent-[#d4af37]"
                      />
                      <span className="font-semibold">{p.nickname}</span>
                      <span className="text-sm text-white/50">{p.name}</span>
                    </label>
                  </li>
                ))}
              </ul>
            )}
            {allPlayers.length > 0 && (
              <button className="btn btn-green w-full">
                Enregistrer les inscriptions
              </button>
            )}
          </form>

          <form action={saveResults} className="card space-y-3 p-4">
            <input type="hidden" name="tournamentId" value={tournament.id} />
            <div className="font-bold text-gold-soft">Enregistrer les résultats</div>
            {entries.length < 2 ? (
              <p className="text-sm text-white/60">
                Inscris au moins 2 joueurs pour saisir les résultats.
              </p>
            ) : (
              <>
                {erreur === "doublon" && (
                  <p className="rounded-lg border border-red-500/50 p-2 text-sm text-red-300">
                    Un même joueur ne peut avoir qu&apos;un seul rôle.
                  </p>
                )}
                <Select label={`🏆 Champion (+${POINTS.champion})`} name="champion" entries={entries} required />
                <Select label={`🥈 Finaliste (+${POINTS.finalist})`} name="finalist" entries={entries} required />
                <Select label={`Demi-finaliste 1 (+${POINTS.semi}) – facultatif`} name="semi1" entries={entries} />
                <Select label={`Demi-finaliste 2 (+${POINTS.semi}) – facultatif`} name="semi2" entries={entries} />
                <p className="text-xs text-white/50">
                  Les autres inscrits reçoivent {POINTS.participant} points de participation.
                </p>
                <button className="btn btn-gold w-full">
                  Valider et attribuer les points
                </button>
              </>
            )}
          </form>
        </>
      )}

      <form action={deleteTournament}>
        <input type="hidden" name="id" value={tournament.id} />
        <ConfirmButton
          message="Supprimer ce tournoi ? Les points associés seront retirés."
          className="btn btn-danger w-full"
        >
          Supprimer le tournoi
        </ConfirmButton>
      </form>
    </div>
  );
}

function Select({
  label,
  name,
  entries,
  required,
}: {
  label: string;
  name: string;
  entries: { playerId: number; nickname: string; name: string }[];
  required?: boolean;
}) {
  return (
    <label className="block space-y-1">
      <span className="text-sm text-white/70">{label}</span>
      <select name={name} required={required} defaultValue="" className="field">
        <option value="">{required ? "— Choisir —" : "— Aucun —"}</option>
        {entries.map((e) => (
          <option key={e.playerId} value={e.playerId}>
            {e.nickname} ({e.name})
          </option>
        ))}
      </select>
    </label>
  );
}
