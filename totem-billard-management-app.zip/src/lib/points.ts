// Barème des points (modifiable ici)
export const POINTS = {
  participant: 10,
  semi: 40,
  finalist: 60,
  champion: 100,
} as const;

export type ResultKey = keyof typeof POINTS;

export const RESULT_LABELS: Record<string, string> = {
  participant: "Participant",
  semi: "Demi-finaliste",
  finalist: "Finaliste",
  champion: "Champion",
};
