import { asc, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { ensureTables } from "@/db/init";
import { players, registrations, tournaments } from "@/db/schema";
import { POINTS } from "@/lib/points";

export type RankedPlayer = {
  id: number;
  name: string;
  nickname: string;
  points: number;
  tournaments: number;
  wins: number;
  rank: number;
};

// Les points sont calculés à chaque affichage à partir des résultats
// des tournois terminés : le classement est donc toujours à jour.
export async function getRanking(): Promise<RankedPlayer[]> {
  await ensureTables();
  const res = await db.execute<{
    id: number;
    name: string;
    nickname: string;
    points: number;
    tournaments: number;
    wins: number;
  }>(sql`
    SELECT p.id, p.name, p.nickname,
      COALESCE(SUM(CASE WHEN t.status = 'done' THEN
        CASE r.result
          WHEN 'champion' THEN ${sql.raw(String(POINTS.champion))}
          WHEN 'finalist' THEN ${sql.raw(String(POINTS.finalist))}
          WHEN 'semi' THEN ${sql.raw(String(POINTS.semi))}
          ELSE ${sql.raw(String(POINTS.participant))} END
        ELSE 0 END), 0)::int AS points,
      COUNT(CASE WHEN t.status = 'done' THEN 1 END)::int AS tournaments,
      COUNT(CASE WHEN t.status = 'done' AND r.result = 'champion' THEN 1 END)::int AS wins
    FROM players p
    LEFT JOIN registrations r ON r.player_id = p.id
    LEFT JOIN tournaments t ON t.id = r.tournament_id
    GROUP BY p.id
    ORDER BY points DESC, wins DESC, lower(p.nickname) ASC
  `);

  let lastPoints = -1;
  let lastRank = 0;
  return res.rows.map((row, i) => {
    if (row.points !== lastPoints) {
      lastRank = i + 1;
      lastPoints = row.points;
    }
    return { ...row, rank: lastRank };
  });
}

export async function getPlayers() {
  await ensureTables();
  return db.select().from(players).orderBy(asc(players.nickname));
}

export async function getTournaments() {
  await ensureTables();
  const res = await db.execute<{
    id: number;
    name: string;
    date: string;
    status: string;
    count: number;
  }>(sql`
    SELECT t.id, t.name, t.date, t.status, COUNT(r.id)::int AS count
    FROM tournaments t
    LEFT JOIN registrations r ON r.tournament_id = t.id
    GROUP BY t.id
    ORDER BY t.date DESC, t.id DESC
  `);
  return res.rows;
}

export async function getTournament(id: number) {
  await ensureTables();
  const [tournament] = await db
    .select()
    .from(tournaments)
    .where(eq(tournaments.id, id));
  if (!tournament) return null;

  const entries = await db
    .select({
      playerId: players.id,
      name: players.name,
      nickname: players.nickname,
      result: registrations.result,
    })
    .from(registrations)
    .innerJoin(players, eq(players.id, registrations.playerId))
    .where(eq(registrations.tournamentId, id))
    .orderBy(desc(registrations.id));

  return { tournament, entries };
}
